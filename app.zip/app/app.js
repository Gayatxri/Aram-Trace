// app.js – adds interactivity to the Aram‑Trace prototype

// Helper to safely base64‑encode Unicode strings
function base64EncodeUnicode(str) {
    // encodeURIComponent converts the string to UTF‑8, escape encodes any sequences
    return btoa(unescape(encodeURIComponent(str)));
}

// QR Code form submission handler
document.addEventListener('DOMContentLoaded', function () {
    const qrForm = document.getElementById('qr-form');
    const qrOutput = document.getElementById('qr-output');
    qrForm.addEventListener('submit', function (event) {
        event.preventDefault();
        // Extract values
        const farmerId = (document.getElementById('farmerId').value || '').trim();
        const cropType = (document.getElementById('cropType').value || '').trim();
        const timestamp = document.getElementById('timestamp').value;
        const gps = (document.getElementById('gps').value || '').trim();
        // Basic validation
        if (!farmerId || !cropType || !timestamp || !gps) {
            qrOutput.textContent = 'Please fill in all fields.';
            qrOutput.style.color = '#c0392b';
            return;
        }
        const dataObject = {
            farmerId: farmerId,
            cropType: cropType,
            timestamp: timestamp,
            gps: gps
        };
        // Convert to base64 and generate a compact code
        const encoded = base64EncodeUnicode(JSON.stringify(dataObject));
        // Use the first 20 characters as the batch code for demonstration
        const batchCode = encoded.substring(0, 20);
        qrOutput.style.color = '#3c8d40';
        qrOutput.textContent = `Batch Code: ${batchCode}`;
    });

    // Route Planner form submission handler
    const routeForm = document.getElementById('route-form');
    const routeOutput = document.getElementById('route-output');
    routeForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const distance = parseFloat(document.getElementById('distance').value);
        const weather = parseFloat(document.getElementById('weather').value);
        const market = parseFloat(document.getElementById('market').value);
        if (isNaN(distance) || isNaN(weather) || isNaN(market)) {
            routeOutput.style.color = '#c0392b';
            routeOutput.textContent = 'Please enter valid numbers for all fields.';
            return;
        }
        const cost = distance + weather + market;
        // Provide a simple recommendation: lower cost suggests better route
        const recommendation = `Total cost (C = d + w + s): ${cost.toFixed(2)}`;
        routeOutput.style.color = '#3c8d40';
        routeOutput.textContent = recommendation;
    });
});